public class Calculator {
    public int num1 { get; set;}
    public int num2 {get; set;}
    public string? operand { get; set;}
}